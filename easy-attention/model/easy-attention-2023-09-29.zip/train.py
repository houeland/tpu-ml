import logging

logging.basicConfig(
    format="%(asctime)s %(levelname)-8s %(message)s",
    level=logging.INFO,
    datefmt="%Y-%m-%d %H:%M:%S",
)
logging.warning("start")

import jax
import jax.numpy as jnp
import haiku as hk
import ml_collections
import optax
from flax.training import train_state

if False:
    from flax.metrics import tensorboard
else:
    tensorboard = None

import model
import dataset

from configs import default as config_lib

config = config_lib.get_config()


def create_model(config: ml_collections.ConfigDict):
    return model.AutoregressiveTransformerModel(
        transformer=model.Transformer(
            num_attention_heads=config.transformer_num_attention_heads,  # type: ignore
            num_layers=config.transformer_num_layers,  # type: ignore
            attention_size_per_head=config.transformer_attention_size_per_head,  # type: ignore
            dropout_rate=config.transformer_dropout_rate,  # type: ignore
            is_training=True,
        ),
        embed_dim=config.model_embed_dim,
        vocab_size=dataset.VOCAB_SIZE,
        is_training=True,
    )


def create_train_state(
    init_rng: jax.random.PRNGKeyArray, config: ml_collections.ConfigDict
):
    m = create_model(config)
    data = dataset.Batch(
        inputs=jnp.zeros(
            (dataset.BATCH_SIZE, dataset.SEQUENCE_LENGTH), dtype=jnp.uint8
        ),
        targets=jnp.ones(
            (dataset.BATCH_SIZE, dataset.SEQUENCE_LENGTH), dtype=jnp.uint8
        ),
    )
    params_rng_key, dropout_rng_key = jax.random.split(init_rng)
    variables = jax.jit(m.init)(
        {"params": params_rng_key, "dropout": dropout_rng_key}, data.inputs
    )
    tx = optax.sgd(config.learning_rate, config.momentum)  # type: ignore
    return train_state.TrainState.create(
        apply_fn=m.apply, params=variables["params"], tx=tx
    )


@jax.jit
def apply_model(state, batch, apply_rng_key):
    dropout_rng_key = apply_rng_key

    def loss_fn(params):
        logits = state.apply_fn(
            {"params": params}, batch.inputs, rngs={"dropout": dropout_rng_key}
        )
        log_probs = jax.nn.log_softmax(logits)  # [B, T, V]
        onehot_targets = jax.nn.one_hot(batch.targets, dataset.VOCAB_SIZE)
        log_likelihood = jnp.sum(onehot_targets * log_probs, axis=-1)  # [B, T]

        # Loss is the average negative log-likelihood per (non-masked) token.
        return -jnp.sum(log_likelihood), {"logits": logits}

    grad_fn = jax.value_and_grad(loss_fn, has_aux=True)
    (loss, aux), grads = grad_fn(state.params)
    accuracy = jnp.mean(jnp.argmax(aux["logits"], -1) == batch.targets)
    return grads, loss, accuracy


@jax.jit
def update_model(state, grads):
    return state.apply_gradients(grads=grads)


def train(
    rng_key: jax.random.PRNGKeyArray, config: ml_collections.ConfigDict, workdir: str
):
    if tensorboard:
        summary_writer = tensorboard.SummaryWriter(workdir)
        summary_writer.hparams(dict(config))
    init_rng, rng_key = jax.random.split(rng_key)
    state = create_train_state(init_rng, config)
    print(f"{state=}")

    num_examples_trained_on = 0
    for batch in dataset.load_from_file("data/generated-easy-attention-dataset.txt"):
        rng_key, apply_rng_key = jax.random.split(rng_key)
        # print(f"{batch=}")
        grads, loss, accuracy = apply_model(state, batch, apply_rng_key)
        state = update_model(state, grads)
        num_examples_trained_on += batch.inputs.shape[0]
        logging.warning(
            f"[{num_examples_trained_on}] loss: {loss}, accuracy: {accuracy}"
        )
        # epoch_loss.append(loss)
        # epoch_accuracy.append(accuracy)
    # train_loss = np.mean(epoch_loss)
    # train_accuracy = np.mean(epoch_accuracy)

    # eval_config = train_config.replace(deterministic=True)
    # predict_config = train_config.replace(deterministic=True, decode=True)


if __name__ == "__main__":
    train_rng = jax.random.key(12345)
    workdir = "./training_workdir/"
    train(train_rng, config, workdir)
    # data = dataset.Batch(
    #     inputs=jnp.array([[1, 2, 3, 4], [5, 6, 7, 8]]),
    #     targets=jnp.array([[2, 3, 4, 5], [6, 7, 8, 9]]),
    # )
    # test_rng = jax.random.PRNGKey(12345)
    # init_rng, apply_rng = jax.random.split(test_rng)
    # state = create_train_state(init_rng, config)
    # initial_params = loss_fn.init(init_rng, data)
    # output = loss_fn.apply(initial_params, apply_rng, data)
    # print(output)


# def train_and_evaluate(config: ml_collections.ConfigDict, workdir: str):
#     for step, batch in enumerate(train_ds.as_numpy_iterator()):
#         # Run optimization steps over training batches and compute batch metrics
#         state = train_step(
#             state, batch
#         )  # get updated train state (which contains the updated parameters)

#     start_step = 0
#     rng = jax.random.key(config.seed)
#     rng, init_rng = jax.random.split(rng)
#     input_shape = (config.per_device_batch_size, config.max_target_length)
#     target_shape = (config.per_device_batch_size, config.max_target_length)

#     m = models.Transformer(eval_config)
#     initial_variables = jax.jit(m.init)(
#         init_rng,
#         jnp.ones(input_shape, jnp.float32),
#         jnp.ones(target_shape, jnp.float32),
#     )

#     # Create train state with Adam optimizer and weight decay.
#     learning_rate_fn = create_learning_rate_schedule(
#         learning_rate=config.learning_rate, warmup_steps=config.warmup_steps
#     )
